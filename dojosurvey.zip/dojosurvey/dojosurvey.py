from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def opening():
    return render_template('open.html')

@app.route('/myprojects')
def myprojects():
   return render_template('myprojects.html')

@app.route('/aboutme')
def aboutme():
   return render_template('aboutme.html')


# @app.route('/extra')
# def pick():
#    return render_template('extra.html')


app.run(debug=True)
